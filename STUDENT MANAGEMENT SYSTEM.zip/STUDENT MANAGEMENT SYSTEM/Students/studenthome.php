<?php
session_start();


if(!isset($_SESSION['username'])) {
    header("location:../login/login3.php");
    exit;
}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Student Dashboard</title>
	
	<?php
	
	include '../css/student_css.php';

	?>
	
</head>
<body>




	<header class="header">
		
		<a href="studenthome.php
		"></a>

		
		

	</header>
	<?php
	
	include '../includes/header2.php';

?>
	

	</div>

</body>
</html>