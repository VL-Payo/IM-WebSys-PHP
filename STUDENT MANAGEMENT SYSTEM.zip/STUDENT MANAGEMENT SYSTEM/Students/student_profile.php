<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:../login/login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";
$data = mysqli_connect($host, $user, $password, $db);

if (isset($_GET['student_id'])) {
    $id = $_GET['student_id'];

    // Get student info
    $sql = "SELECT * FROM user WHERE id='$id'";
    $result = mysqli_query($data, $sql);
    $info = $result->fetch_assoc();

    // Check if form submitted
    if (isset($_POST['update'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];
        $age = $_POST['age'];
        $gender= $_POST['gender'];

        // Update database
        $update_sql = "UPDATE user SET username='$username', email='$email', phone='$phone', age='$age', gender='$gender' WHERE id=$id";

        $update_result = mysqli_query($data, $update_sql);

        if ($update_result) {
            $_SESSION['message'] = "Student information updated successfully";
            header("location:../Admin/view_student.php");
            exit();
        } else {
            $_SESSION['message'] = "Failed to update student information";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <?php include '../css/admin_css.php'; ?>
    <style type="text/css">
        label {
            display: inline-block;
            width: 100px;
            text-align: right;
            padding-top: 10px;
            padding-bottom: 10px;
            padding-right: 50px;
        }
        .div_design {
            background-color: gray;
            width: 400px;
            padding-bottom: 70px;
            padding-top: 70px;
        }
    </style>
</head>
<body>



<header class="header">
    
    <a href="studenthome.php">Student Dashboard</a>
    <div class="logout">
			
			<a href="../logout/logout2.php" class="btn btn-primary">Logout</a>

		</div>
</header>
<?php
	
	include '../includes/header.php';

?>

<div class="content">
    <center>
        <h1>Update Student</h1>
        <div class= "div_design">
            <form method="POST">
                <div>
                    <label> Username </label>
                    <input type="text" name="username" value="<?php if(isset($info)) echo $info['username']; ?>">
                </div>
                
                <div>
                    <label> Phone </label>
                    <input type="text" name="phone" value="<?php if(isset($info)) echo $info['phone']; ?>">
                </div>
            
                <div>
                    <label> Gender </label>
                    <input type="text" name="gender" value="<?php if(isset($info)) echo $info['gender']; ?>">
                </div>
                
                <div>
                    <input class="btn btn-success" type="submit" name="update" value="Update">
                </div>
            </form>
        </div>
        
    </center>
</div


</body>
</html>