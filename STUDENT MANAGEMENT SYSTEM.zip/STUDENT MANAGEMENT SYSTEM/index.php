<?php

error_reporting(0);
session_start();
session_destroy();
if($_SESSION['message'])
{
	$message=$_SESSION['message'];

	echo "<script type='text/javascript'>   
	alert('$message');
	</script>";
}
$host="localhost";
$user="root";
$password="";
$db="schoolproject";

$data=mysqli_connect($host,$user,$password,$db);



?>



<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Student Management System</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"> -->

	<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 -->
<!-- Optional theme -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
 -->
<!-- Latest compiled and minified JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>

	<nav>
		<label class="logo">kean school</label>

		<ul>
			<li><a href="">Home</a></li>
			<li><a href="">Contact</a></li>
			<li><a href="index2.php">Admission</a></li>
			<li><a href="login1.php" class="btn btn-success">Login</a></li>
		</ul>
	</nav>


	<div class="section1">
		
		<label class="img_text">We Teach Students With Care</label>
		<img class="main_img" src="wvsu.jpeg">
	</div>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="welcome_img" src="school2.jpg">
				
			</div>

			<div class="col-md-8">

				<h1>Welcome to W-School</h1>

				<p>MEMS has been committed to global learning long before it became an indispensable feature of contemporary education. Established in 1997, we proudly stand as the 1st English medium school in Bangladesh to adopt both Pearson Edexcel and Cambridge curriculum (in O and A levels), drawing together students in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.MEMS has been committed to global learning long before it became an indispensable feature of contemporary education. Established in 1997, we proudly stand as the 1st English medium school in Bangladesh to adopt both Pearson Edexcel and Cambridge curriculum (in O and A levels), drawing together students in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
				
			</div>
			

		</div>
		

	</div>


	<center>
		<h1>Our Teachers</h1>
	</center>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="teacher" src="teacher1.jpg">

				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="teacher2.jpg">
				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="teacher3.jpg">
				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
				
			</div>
			

		</div>
		

	</div>






	<center>
		<h1>Our Courses</h1>
	</center>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="teacher" src="web.jpg">
				<h3>Web Development</h3>
				
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="graphic.jpg">
				<h3>Graphics Design</h3>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="marketing.png">
				<h3>Marketing</h3>
				
			</div>
			

		</div>
		

	</div>



  
	</div>


	<footer>
		<h3 class="footer_text">project mam keia
		</h3>
	</footer> -->




	<!DOCTYPE html>
<html lang="en">
<head>
  <title>WVNHS</title>
  <meta property="og:title" content="Soft UI Pro" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta charset="utf-8" />
  <meta property="twitter:card" content="summary_large_image" />
  <style data-tag="reset-style-sheet">
    html {
      line-height: 1.15;
    }
    body {
      margin: 0;
    }
    * {
      box-sizing: border-box;
      border-width: 0;
      border-style: solid;
    }
    p,
    li,
    ul,
    pre,
    div,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    figure,
    blockquote,
    figcaption {
      margin: 0;
      padding: 0;
    }
    button {
      background-color: transparent;
    }
    button,
    input,
    optgroup,
    select,
    textarea {
      font-family: inherit;
      font-size: 100%;
      line-height: 1.15;
      margin: 0;
    }
    button,
    select {
      text-transform: none;
    }
    button,
    [type="button"],
    [type="reset"],
    [type="submit"] {
      -webkit-appearance: button;
    }
    button::-moz-focus-inner,
    [type="button"]::-moz-focus-inner,
    [type="reset"]::-moz-focus-inner,
    [type="submit"]::-moz-focus-inner {
      border-style: none;
      padding: 0;
    }
    button:-moz-focus,
    [type="button"]:-moz-focus,
    [type="reset"]:-moz-focus,
    [type="submit"]:-moz-focus {
      outline: 1px dotted ButtonText;
    }
    a {
      color: inherit;
      text-decoration: inherit;
    }
    input {
      padding: 2px 4px;
    }
    img {
      display: block;
    }
    html {
      scroll-behavior: smooth;
    }
  </style>
  <style data-tag="default-style-sheet">
    html {
      font-family: Open Sans;
      font-size: 1rem;
    }
    body {
      font-weight: 400;
      font-style: normal;
      text-decoration: none;
      text-transform: none;
      letter-spacing: normal;
      line-height: 1.625;
      color: var(--dl-color-secondary-400);
      background-color: var(--dl-color-gray-white);
      fill: var(--dl-color-secondary-400);
    }
  </style>
  <link rel="stylesheet" href="https://unpkg.com/animate.css@4.1.1/animate.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&amp;display=swap" data-tag="font" />
  <link rel="stylesheet" href="https://unpkg.com/@teleporthq/teleport-custom-scripts/dist/style.css" />
  <style>
    html * {
      -webkit-font-smoothing: antialiased;
    }
    input::placeholder,
    textarea::placeholder {
      color: #d2d6da;
    }
  </style>
</head>
<body>
<nav style="background-color: #4169E1; padding: 10px;">
    <label class="logo" style="color: #ffffff; font-size: 24px; font-weight: bold;">WVNHS</label>
    <ul style="list-style-type: none; margin: 0; padding: 0;">
        <li style="display: inline-block; margin-right: 10px;"><a href="#" style="color: #ffffff; text-decoration: none;">Home</a></li>
        <li style="display: inline-block; margin-right: 10px;"><a href="#" style="color: #ffffff; text-decoration: none;">Contact</a></li>
        <li style="display: inline-block; margin-right: 10px;"><a href="index2.php" style="color: #ffffff; text-decoration: none;">Admission</a></li>
        <li style="display: inline-block;"><a href="login/login1.php" class="btn btn-success" style="color: white; text-decoration: none; padding: 8px 16px; background-color: #800080; border: none; border-radius: 4px;">Login</a></li>
    </ul>
</nav>
  <link rel="stylesheet" href="components/style3.css" />
  <div>
    <link rel="stylesheet" href="css/style.css" />
    <div>
      <link href="components/index.css" rel="stylesheet" />
      <div class="home-container">
        <div class="home-hero">
          <div class="home-container1">
            <div class="home-card">
              <h1 class="home-text HeadingOne">We Teach Students With Care.</h1>
              <h1 class="home-text1 HeadingOne">Choose the best</h1>
              <span class="home-text2 Lead">Start your journey now and become the best among the rest.</span>
              <div class="home-container2">
                <div class="home-container3">
                  <div class="primary-pink-button-container primary-pink-button-root-class-name">
                    <button class="primary-pink-button-button button ButtonSmall"><span><a href="login/login1.php">Sign In</a></span></button>
                  </div>
                </div>
                <div class="outline-gray-button-container">
                  <button class="outline-gray-button-button button ButtonSmall"><span><a href="index2.php">Sign Up</a></span></button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <section class="home-container4">
		<img src='image/curved6-1500h.jpg' class="home-image" />
          <div class="home-container5">
            <h1 class="home-text3">Inspiring Curiosity, Igniting Passion</h1>
            <span class="home-text4">The most esteemed individuals in educational history are those who sought nothing for themselves but gave everything for the growth and enlightenment of others.</span>
          </div>
        </section>
      </div>
      <footer class="footer-footer">
        <div class="footer-container">
          <div class="footer-container1">
            <span class="footer-text">WVNHS</span>
            <span>Copyright © West Visayas National High School.</span>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <script defer="" src="https://unpkg.com/@teleporthq/teleport-custom-scripts"></script>
</body>
</html>
