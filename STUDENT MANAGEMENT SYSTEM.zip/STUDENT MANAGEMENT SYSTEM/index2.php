<?php
// ADMISSION FOLDER NI
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";


$data = mysqli_connect($host, $user, $password, $db);


if (!$data) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['apply'])) {
    // Server-side validation and sanitization
    $name = htmlspecialchars(trim($_POST['name']));
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $phone = preg_replace("/[^0-9]/", "", $_POST['phone']); // Remove non-numeric characters
    $message = htmlspecialchars(trim($_POST['message']));
    
    // Check if any field is empty
    if(empty($name) || empty($email) || empty($phone) || empty($message)) {
        $errors = [];
        if(empty($name)) {
            $errors[] = "Name is required.";
        }
        if(empty($email)) {
            $errors[] = "Email is required.";
        }
        if(empty($phone)) {
            $errors[] = "Phone number is required.";
        }
        if(empty($message)) {
            $errors[] = "Message is required.";
        }
        $_SESSION['message'] = implode(" ", $errors);
    } else {
        // Insert data into the database
        $sql = "INSERT INTO admission (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
        if(mysqli_query($data, $sql)) {
            // Set success message
            $_SESSION['message'] = "Form submitted successfully!";
            // Redirect to a different page after form submission
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['message'] = "Error: " . $sql . "<br>" . mysqli_error($data);
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Management System</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <?php include_once 'css/admin_css.php' ?>
    <style>
        /* Inline CSS */
        .admission_form {
            margin-top: 50px; /* Adjust margin as needed */
            text-align: center;
        }

        .adm_int {
            margin-bottom: 15px;
        }
        
        .label_text {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .input_deg {
            width: 50%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .input_txt {
            width: 50%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            height: 150px; /* Adjust height as needed */
        }
    </style>
</head>
<body>
<?php include 'includes/header3.php'; ?>
    <div align="center" class="admission_form">
        <h1 class="adm">Admission Form</h1>
        <?php if(isset($_SESSION['message'])): ?>
        <div class="alert <?php echo (strpos($_SESSION['message'], "successfully") !== false) ? 'alert-success' : 'alert-danger'; ?>">
            <?php echo $_SESSION['message']; ?>
        </div>
        <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="adm_int">
                <label class="label_text">Name</label>
                <input class="input_deg" type="text" name="name">
            </div>
            <div class="adm_int">
                <label class="label_text">Email</label>
                <input class="input_deg" type="text" name="email">
            </div>
            <div class="adm_int">
                <label class="label_text">Phone</label>
                <input class="input_deg" type="text" name="phone" maxlength="11">
            </div>
            <div class="adm_int">
                <label class="label_text">Message</label>
                <textarea class="input_txt" name="message"></textarea>
            </div>
            <div class="adm_int">
                <input class="btn btn-primary" id="submit" type="submit" value="Apply" name="apply">
            </div>
            
        </form>
        
    </div>
</body>
</html>


<?php

mysqli_close($data);
?>
