<?php
session_start();

	if(!isset($_SESSION['username']))
	{
		header("location:login.php");
		
	}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Student Dashboard</title>
	
	<?php
	
	include '../css/student_css.php'

	?>
	
</head>
<body>

	<header class="header">
		
		<a href="">Student Dashboard</a>

		<div class="logout">
			
			<a href="../logout/logout.php" class="btn btn-primary">Logout</a>

		</div>

	</header>


		
	<?php
	
	include '../Students/student_sidebar.php'

	?>


	


	</div>

</body>
</html>