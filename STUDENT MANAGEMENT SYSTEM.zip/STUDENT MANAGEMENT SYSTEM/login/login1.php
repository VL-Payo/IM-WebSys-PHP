<!-- GENERAL LOG IN -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login Form</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <style>
        body {
            background: url("image/wvsu.png") no-repeat;
            background-size: cover;
        }

        .title_deg {
            color: #D4A94B;
        }
        .button-19 {
        appearance: button;
         background-color: #1899D6;
  border: solid transparent;
  border-radius: 16px;
  border-width: 0 0 4px;
  box-sizing: border-box;
  color: #000000;
  cursor: pointer;
  display: inline-block;
  font-family: din-round,sans-serif;
  font-size: 15px;
  font-weight: 700;
  letter-spacing: .8px;
  line-height: 20px;
  margin-top: 20px;
  outline: none;
  overflow: visible;
  padding: 22px 26px;
  
  text-align: center;
  text-transform: uppercase;
  touch-action: manipulation;
  transform: translateZ(0);
  transition: filter .2s;
  user-select: none;
  -webkit-user-select: none;
  vertical-align: middle;
  white-space: nowrap;
  width: 40%;
}

.button-19:after {
  background-clip: padding-box;
  background-color: #1CB0F6;
  border: solid transparent;
  border-radius: 16px;
  border-width: 0 0 4px;
  bottom: -4px;
  content: "";
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  z-index: -1;
}

.button-19:main,
.button-19:focus {
  user-select: auto;
}

.button-19:hover:not(:disabled) {
  filter: brightness(1.1);
  -webkit-filter: brightness(1.1);
}

.button-19:disabled {
  cursor: auto;
}

.button-19:active {
  border-width: 4px 0 0;
  background: none;
}
.close {
        font-size: 24px;
}
    </style>

   
</head>
<body>

    <center>

        <div class="form_deg">

            <center class="title_deg">
                Login Form

                <h4>
                    <?php 
                    error_reporting(0);
                    session_start();
                    session_destroy();
                    echo $_SESSION['loginMessage'];
                    ?>
                </h4>
            </center>
            
            <form action="login.php" method="POST" class="login_form">
                <div>
                    <button class="button-19" role="button" type="submit" name="userType" value="admin">Admin</button>
                </div>
            </form>

            <form action="login3.php" method="POST" class="login_form">
                <div>
                    <button class="button-19" role="button" type="submit" name="userType" value="student">Student</button>
                </div>
                <div style="position: absolute; top: 40px; left: 50px;">
                    <a href="../index.php" button type="button" class="close" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
                </div>
            </form>
        </div>

    
    </center>

</body>
</html>
