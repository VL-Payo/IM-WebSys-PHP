<?php

error_reporting(0);
session_start();

if($_SESSION['message'])
{
	$message=$_SESSION['message'];

	echo "<script type='text/javascript'>   
	alert('$message');
	</script>";
}
$host="localhost";
$user="root";
$password="";
$db="schoolproject";

$data=mysqli_connect($host,$user,$password,$db);

$sql="SELECT * FROM teacher2";

$result=mysqli_query($data,$sql);

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<title>Student Dashboard</title>
	
	<?php
	
	include '../css/student_css.php';

	?>

	<style type="text/css">

		


		
		.col-md-4{

			padding-left: 80px;
			padding-top: 40px;
		}

	</style>
	
</head>
<body>
<?php
	
	include '../includes/header.php';

	?>


	<header class="header">



	</header>


		
	

	
	

	<center>
		<h1>Teachers</h1>
	</center>


	<div class="container">
		<?php 
	while($info=$result->fetch_assoc())
	{

	
		?>

		<div class="row">

			<div class="col-md-4">

				<img class="teacher" src="<?php echo "{$info['image']}"?>">


				<h3><?php echo "{$info['description']}"?></h3>
				<h5><?php echo "{$info['description']}"?></h5>

				<p></p>
				
			</div>

			
			
		<?php
		}

		?>
		</div>
		

	</div>

</body>



		
	</div>


	

</body>
</html>