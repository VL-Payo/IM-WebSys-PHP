<?php
session_start();

if(!isset($_SESSION['username'])) {
    header("location:../login/login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:../login/login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";
$data = mysqli_connect($host, $user, $password, $db);

if(isset($_POST['add_teacher'])) {
    $teacher_name = mysqli_real_escape_string($data, $_POST['name']);
    $teacher_description = mysqli_real_escape_string($data, $_POST['description']);
    
    
    if(isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_destination = "./image/" . $file_name;
        $file_db_path = "image/" . $file_name;
        
        
        if(move_uploaded_file($file_tmp, $file_destination)) {
            
            $sql = "INSERT INTO teacher (name, description, image) VALUES ('$teacher_name', '$teacher_description', '$file_db_path')";
            $result = mysqli_query($data, $sql);

            
            if($result) {
                echo "Teacher added successfully.";
            } else {
                echo "Error inserting teacher: " . mysqli_error($data);
            }
        } else {
            echo "Error uploading file.";
        }
    } else {
        echo "Please select an image file.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>

    <style type="text/css">
        .body{

            background-color: lightyellow;
        }
        .div_design {
            background-color: lightyellow; /* Changed background color to light yellow */
            padding-top: 100px;
            padding-bottom: 100px;
            width: 500px;
        }
    </style>

    <?php
    include '../css/admin_css.php';
    ?>
</head>
<body>
<?php

include '../includes/header.php';

?>
    <header class="header">
        <a href=""></a>
    </header>
    <div class="content">
        <center>
            <h1>Add teacher</h1><br><br>
            <div class="div_design">
                <div>
                    <form action="#" method="POST" enctype="multipart/form-data">
                        <div>
                            <label>Teacher Name : </label>
                            <input type="text" name="name" required>
                        </div>
                        <div>
                            <label>Description : </label>
                            <textarea name="description" required></textarea>
                        </div>
                        <div>
                            <label>Add 1x1 Image  : </label>
                            <input type="file" name="image" required>
                        </div>
                        <div>
                            <input type="submit" name="add_teacher" value="Add Teacher" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </center>
    </div>
</body>
</html>

