<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:../login/login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";
$data = mysqli_connect($host, $user, $password, $db);

if (isset($_GET['student_id'])) {
    $id = $_GET['student_id'];

    // Get student info
    $sql = "SELECT * FROM user WHERE id='$id'";
    $result = mysqli_query($data, $sql);
    $info = $result->fetch_assoc();

    if (isset($_POST['update'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];
        $age = $_POST['age'];
        $gender= $_POST['gender'];

       
        $update_sql = "UPDATE user SET username='$username', email='$email', phone='$phone', age='$age', gender='$gender' WHERE id=$id";

        $update_result = mysqli_query($data, $update_sql);

        if ($update_result) {
            $_SESSION['message'] = "Student information updated successfully";
            header("location:view_student.php");
            exit();
        } else {
            $_SESSION['message'] = "Failed to update student information";
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <?php include '../css/admin_css.php'; ?>
    <style>
        body {
            background-color: #FFFFE0; 
        }

        label {
            display: inline-block;
            width: 100px;
            text-align: right;
            padding-top: 10px;
            padding-bottom: 10px;
            color: #87CEEB;
        }
        .div_design {
            background-color: #FFFFE0; 
            width: 400px;
            padding-bottom: 70px;
            padding-top: 70px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            border: 1px solid #87CEEB; 
            padding: 5px;
            border-radius: 3px;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #87CEEB; 
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #6495ED; 
        }
    </style>
</head>
<body>

<header class="header">
    <a href=""></a>
</header>

<?php include '../includes/header.php'; ?>

<div class="content">
    <center>
        <h1>Update Student</h1>
        <div class="div_design">
            <form method="POST">
                <div>
                    <label>Username</label>
                    <input type="text" name="username" value="<?php if(isset($info)) echo $info['username']; ?>">
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" name="email" value="<?php if(isset($info)) echo $info['email']; ?>">
                </div>
                <div>
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php if(isset($info)) echo $info['phone']; ?>">
                </div>
                <div>
                    <label>Age</label>
                    <input type="text" name="age" value="<?php if(isset($info)) echo $info['age']; ?>">
                </div>
                <div>
                    <label>Gender</label>
                    <input type="text" name="gender" value="<?php if(isset($info)) echo $info['gender']; ?>">
                </div>
                <div>
                    <label>Password</label>
                    <input type="password" name="password" value="<?php if(isset($info)) echo $info['password']; ?>">
                </div>
                <div>
                    <input type="submit" class="btn btn-success" name="update" value="Update">
                </div>
            </form>
        </div>
    </center>
</div>

</body>
</html>
