
<?php
error_reporting(0);
session_start();

	if(!isset($_SESSION['username']))
	{
		header("location:../login/login.php");
	}
	elseif ($_SESSION['usertype']=='student') {
		header("location:../login/login.php");
	}

	$host="localhost";
	$user="root";
	$password="";
	$db="schoolproject";
//muni mag connect sang aton nga database gamit mysqli
	$data=mysqli_connect($host,$user,$password,$db);
	$sql="SELECT *FROM user";
	$result=mysqli_query($data,$sql);

 


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>

    <?php include '../css/admin_css.php'; ?>

    <style type="text/css">
        body {
            background-color: #FFFFE0; /* Light yellow */
        }

        .table_th {
            padding: 18px;
            font-size: 18px;
        }

        .table_td {
            padding: 18px;
        }

        .table_image {
            width: 100px;
            height: 100px;
        }
    </style>
</head>
<body>

<?php include '../includes/header.php'; ?>

<header class="header">
    <a href=""></a>
</header>

<div class="content">
    <center>
        <h1>Student Data</h1>

        <?php
        if ($_SESSION['message']) {
            echo $_SESSION['message'];
        }
        unset($_SESSION['message']);
        ?>

        <br><br>

        <table border="5px">
            <tr>
                <th class="table_th">Username</th>
                <th class="table_th">Email</th>
                <th class="table_th">Phone</th>
                <th class="table_th">Age</th>
                <th class="table_th">Gender</th>
                <th class="table_th">Image</th>
                <th class="table_th">Password</th>
                <th class="table_th">Delete</th>
                <th class="table_th">Update</th>
            </tr>

            <?php
            while ($info = $result->fetch_assoc()) {
                ?>
                <tr>
                    <td class="table_td"><?php echo "{$info['username']}"; ?></td>
                    <td class="table_td"><?php echo "{$info['email']}"; ?></td>
                    <td class="table_td"><?php echo "{$info['phone']}"; ?></td>
                    <td class="table_td"><?php echo "{$info['age']}"; ?></td>
                    <td class="table_td"><?php echo "{$info['gender']}"; ?></td>
                    <td class="table_td">
                        <img src="image/<?php echo "{$info['image']}"; ?>" class="table_image">
                    </td>
                    <td class="table_td"><?php echo "{$info['password']}"; ?></td>
                    <td class="table_td">
                        <?php echo "<a onClick=\"javascript:return confirm('Are you sure to delete the data?');\" class='btn btn-danger' href='delete.php?student_id={$info['id']}'>Delete</a>"; ?>
                    </td>
                    <td class="table_td">
                        <?php echo "<a class='btn btn-primary' href='update_student.php?student_id={$info['id']}'>Update</a>"; ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    </center>
</div>

</body>
</html>
