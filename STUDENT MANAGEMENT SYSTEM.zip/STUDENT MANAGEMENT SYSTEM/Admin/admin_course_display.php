<?php
error_reporting(0);
session_start();

if ($_SESSION['message']) {
    $message = $_SESSION['message'];

    echo "<script type='text/javascript'>   
    alert('$message');
    </script>";
}
$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM course";

$result = mysqli_query($data, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <title>Student Dashboard</title>

    <?php
    include '../css/student_css.php';
    ?>

    <style type="text/css">
        .table_th {
            padding: 20px;
            font-size: 20px;
        }

        .table_td {
            padding: 10px;
        }

        .col-md-4 {
            padding-left: 80px;
            padding-top: 40px;
        }

        .course {
            width: 100%; /* Ensure the image fits within its container */
        }
    </style>

</head>

<body>
	<header>

	<?php
include '../includes/header.php';
?>
   
	</header>


<div class="content">
    <h1>View All Teacher Data</h1>
    <table border="1px">
        <tr>
            <th class="table_th">Course Name</th>
            <th class="table_th">Course Description</th>
            <th class="table_th">Level</th>
			<th class="table_th">Status</th>
        </tr>

        <?php while ($info = $result->fetch_assoc()) { ?>
            <tr>
                <td class="table_td"> <?php echo "{$info['name']}" ?></td>
                <td class="table_td"> <?php echo "{$info['description']}" ?></td>
                <td class="table_td"> <?php echo "{$info['level']}" ?></td>
				<td class="table_td"> <?php echo "{$info['status']}" ?></td>
            </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
