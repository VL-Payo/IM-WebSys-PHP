<?php
session_start();

	if(!isset($_SESSION['username']))
	{
		header("location:../login/login.php");
	}
	


	$host="localhost";
	$user="root";
	$password="";
	$db="schoolproject";

	$data=mysqli_connect($host,$user,$password,$db);

	$sql="SELECT * from admission";
	$result=mysqli_query($data, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <?php include '../css/admin_css.php'; ?>
    <style>
        .table-container {
            padding-left: 120px; /* Adjust as needed */
        }
    </style>
</head>
<body style="background-color: #FFFFE0;"> <!-- Add light yellow background -->

<?php include '../includes/header.php'; ?>

<div class="content">
    <center>
        <h1>Applied For Admission</h1>
        <div class="table-container">
            <table style="border-collapse: collapse; width: 80%; margin: 20px auto; background-color: white; border: 1px solid #333;">
                <tr>
                    <th style="padding: 20px; font-size: 20px; border: 1px solid #333;">Name</th>
                    <th style="padding: 20px; font-size: 20px; border: 1px solid #333;">Email</th>
                    <th style="padding: 20px; font-size: 20px; border: 1px solid #333;">Phone</th>
                    <th style="padding: 20px; font-size: 20px; border: 1px solid #333;">Message</th>
                </tr>

                <?php
                while($info=$result->fetch_assoc()) {
                ?>
                <tr>
                    <td style="padding: 20px; border: 1px solid #333;"><?php echo "{$info['name']}"; ?></td>
                    <td style="padding: 20px; border: 1px solid #333;"><?php echo "{$info['email']}"; ?></td>
                    <td style="padding: 20px; border: 1px solid #333;"><?php echo "{$info['phone']}"; ?></td>
                    <td style="padding: 20px; border: 1px solid #333;"><?php echo "{$info['message']}"; ?></td>
                </tr>
                <?php 
                }
                ?>
            </table>
        </div>
    </center>
</div>

</body>
</html>

