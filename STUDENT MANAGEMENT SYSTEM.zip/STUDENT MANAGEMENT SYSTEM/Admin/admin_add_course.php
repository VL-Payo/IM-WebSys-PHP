<?php
session_start();

if(!isset($_SESSION['username'])) {
    header("location:login.php");
    exit(); // Add an exit after redirection
} 

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";
$data = mysqli_connect($host, $user, $password, $db);

if(isset($_POST['add_course'])) {
    $course_name = mysqli_real_escape_string($data, $_POST['name']);
    $course_description = mysqli_real_escape_string($data, $_POST['description']);
    $course_level = (int)$_POST['level'];
    $course_status = mysqli_real_escape_string($data, $_POST['status']);
    
    // Validation for course level
    if (!is_numeric($course_level) || $course_level < 0 || $course_level > 999) {
        echo "Invalid course level. Please enter a number between 0 and 999.";
        exit();
    }
    
    // Validation for course status
    if (!in_array($course_status, ['active', 'inactive'])) {
        echo "Invalid course status. Please choose either 'active' or 'inactive'.";
        exit();
    }
    
    // Prepare the SQL statement with placeholders
    $sql = "INSERT INTO course (name, description, level, status) VALUES (?, ?, ?, ?)";
    
    // Prepare the statement
    $stmt = mysqli_prepare($data, $sql);
    
    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ssis", $course_name, $course_description, $course_level, $course_status);
    
    // Execute the statement
    $result = mysqli_stmt_execute($stmt);
    
    // Check if the statement was executed successfully
    if($result) {
        echo "Course added successfully.";
    } else {
        echo "Error inserting your course: ". mysqli_error($data);
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>

    <style type="text/css">
      .body{

            background-color: lightyellow;
        }
      .div_design {
            background-color: lightyellow; 
            padding-top: 100px;
            padding-bottom: 100px;
            width: 60%;
        }
        label {
            padding-top: 30px;
            }
        .input_deg {
            width: 50%;
            height: 40px;
            border-radius: 10px;
            text-align: center;
        }
       
    </style>

    <?php
    include '../css/admin_css.php';
  ?>
</head>
<body>
<?php

include '../includes/header.php';

?>
    <header class="header">
        <a href=""></a>
    </header>
    <div class="content">
        <center>
            <h1>Add Course</h1><br><br>
            <div class="div_design">
                <div>
                    <form action="#" method="POST" enctype="multipart/form-data">
                        <div>
                            <label>Course Name: </label>
                            <input type="text" name="name" required>
                        </div>
                        <div>
                            <label>Course Description: </label>
                            <textarea name="description" required></textarea>
                        </div>
                        <div>
                            <label>Course Level: </label>
                            <input type="number" name="level" min="0" max="999" required>
                        </div>
                        <div>
                            <label>Course Status: </label>
                            <select name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div>
                            <input type="submit" name="add_course" value="Add Course" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </center>
    </div>
</body>
</html>