<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:../login/login.php");
    exit(); 
}


function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";
$data = mysqli_connect($host, $user, $password, $db);

$errors = array();

if (isset($_POST['add_student'])) {
    $username = sanitize_input($_POST['name']);
    $user_email = sanitize_input($_POST['email']);
    $user_phone = sanitize_input($_POST['phone']);
    $user_password = sanitize_input($_POST['password']);
    $usertype = "student";
    $user_age = sanitize_input($_POST['age']);
    $user_gender = sanitize_input($_POST['gender']);
    $user_image = $_FILES['image']['name']; 

    
    if (empty($username)) {
        $errors[] = "Username is required";
    }
    if (empty($user_email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    if (empty($user_phone)) {
        $errors[] = "Phone number is required";
    } elseif (!preg_match("/[0-9]/", $user_phone)) { 
        $errors[] = "Invalid phone number format";
    }

    
    $check = "SELECT * FROM user WHERE username='$username'";
    $check_user = mysqli_query($data, $check);
    $row_count = mysqli_num_rows($check_user);

    if ($row_count == 1) {
        $errors[] = "Username already exists. Please choose a different one.";
    } else {
        // Insert user data into the database
        $sql = "INSERT INTO user (username, email, phone, usertype, age, gender, image, password) VALUES ('$username', '$user_email', '$user_phone', '$usertype', '$user_age', '$user_gender', '$user_image', '$user_password')";
        $result = mysqli_query($data, $sql);

        if ($result) {
            echo "<script type='text/javascript'>alert('Data Upload success');</script>";
        } else {
            echo "Upload Failed Try Again";
        }
    }
} 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <?php include '../css/admin_css.php'; ?>
    <style type="text/css">
        body {
            background-color: #FFFFE0; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

       

        header .logo {
            color: #D4A94B;
            font-size: 24px;
            font-weight: bold;
        }

        .content {
            margin: 50px auto;
            width: 60%;
            background-color: #fffec8; /* Light yellow */
            padding: 20px;
            border-radius: 10px;
        }

        label {
            display: inline-block;
            width: 150px;
            text-align: right;
            padding-top: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="password"],
        input[type="file"] {
            width: 300px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #D4A94B;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #D4A94B;
        }

        .error {
            color: red;
        }
    </style>
 
</head>
<body>


<?php include '../includes/header.php'; ?>

<div class="content">
    <center>
        <h1>Add Student</h1>
        <i class="icon-people menu-icon"></i>
        <div class="div_design">
            <form action="#" method="POST" enctype="multipart/form-data"> 
                <div>
                    <label>Username</label>
                    <input type="text" name="name" value="<?php if (isset($_POST['name'])) echo htmlspecialchars($_POST['name']); ?>">
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" name="email" value="<?php if (isset($_POST['email'])) echo htmlspecialchars($_POST['email']); ?>">
                </div>
                <div>
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php if (isset($_POST['phone'])) echo htmlspecialchars($_POST['phone']); ?>" maxlength="11">
                </div>
                <div>
                    <label>Age</label>
                    <input type="number" name="age" value="<?php if (isset($_POST['age'])) echo htmlspecialchars($_POST['age']); ?>">
                </div>
                <div>
                    <label>Gender</label>
                    <input type="text" name="gender" value="<?php if (isset($_POST['gender'])) echo htmlspecialchars($_POST['gender']); ?>">
                </div>
                <div>
                    <label>Profile Picture</label>
                    <input type="file" name="image"> 
                <div>
                    <label>Password</label>
                    <input type="password" name="password">
                </div>
                <div>
                    <input type="submit" class="btn btn-primary" name="add_student" value="Add Student">
                </div>
            </form>
            <?php if (!empty($errors)) : ?>
                <div class="error">
                    <?php foreach ($errors as $error) : ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </center>
</div>
</body>
</html>
