<?php


// next nga ubrahon is connect ang studenthome saton nga database (DONE)


// ga invalid number format sa add_students kay oha karon LINE 42 ADD_STUDENT (DONE)

//dayon butangan ta delete button nga ga delete man pati sa database (DONE)


// next nga ubrahon is ang aton nga log in sa student ma gana nga ga connect sa studenthome.php since wala pa ga connect kag same lang gna connectan sang admin (DONE)


// kung mag log in sa student's log in nga file tas ibutang mo ang admin nga account nga username: "admin" password: "1234" (DONE)

//css sang studenthome asikasuhon ta nalang



//SAYLO ANG ADMIN NGA TEMPLATE SA STUDENTS

// BUTANGAN TA PICTURES ATON NGA INDEX.PHP

//seperate file ang teachers display

//dugangan grades nga attribute ngitaan ta lang paagi

//arrange lng gd homepage


// butangan sang picture ang add student

// dugangan ta student profile 

//butangan ang student home unod

// figure out paano mag send message from student to admin tulog dnay ah

// sa view teacher maka edit ka para sa admin lang pero sa kung mag saylo sa students indi pwede ma edit

?> 