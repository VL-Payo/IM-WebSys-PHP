<?php
session_start();

$host = "localhost";
$user = "root";
$password = "";
$db = "schoolproject";

$data = mysqli_connect($host, $user, $password, $db);

if ($data === false) {
    die("Connection error");
}

if (isset($_POST['apply'])) {

    
    $data_name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $data_email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $data_phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $data_message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    //muni mag limit nga asta lng 11 ang numbers ky sa pilipinas 11 lng asta ang numbers sa sim
    $data_phone = substr($data_phone, 0, 11);

    if (empty($data_name) || empty($data_email) || empty($data_phone)) {
        $_SESSION['message'] = "Please put your information properly.";
        header("location:index2.php");
        exit; 
    }

    
    $check_query = "SELECT COUNT(*) AS count FROM admission WHERE phone='$data_phone'";
    $check_result = mysqli_query($data, $check_query);
    $row = mysqli_fetch_assoc($check_result);
    if ($row['count'] > 0) {
        $_SESSION['message'] = "Phone number already exists. Please provide a different phone number.";
        header("location:index2.php");
        exit; 
    }

    
    $sql = "INSERT INTO admission (name, email, phone, message) VALUES ('$data_name', '$data_email', '$data_phone', '$data_message')";
    $result = mysqli_query($data, $sql);

    if ($result) {
        $_SESSION['message'] = "Your application was sent successfully.";
        header("location:index2.php");
        exit; 
    } else {
        $_SESSION['message'] = "Apply failed. Please try again later.";
        header("location:index2.php");
        exit; 
    }
}

?>
